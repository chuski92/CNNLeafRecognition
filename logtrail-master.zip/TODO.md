* Explain how it operates in multiple timezones
* Add warning saying Kibana plugins are not officially supported in currently
* Add context based URL routing, so URL copy & paste will work
